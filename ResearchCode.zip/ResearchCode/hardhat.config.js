/**
* @type import('hardhat/config').HardhatUserConfig
*/

require('dotenv').config();
require("@nomiclabs/hardhat-ethers");

const { API_URL, PRIVATE_KEY } = process.env;

/* Ropsten Deploy */ 
module.exports = {
   solidity: "0.7.3",
   defaultNetwork: "ropsten",
   networks: {
      hardhat: {},
      ropsten: {
         url: API_URL,
         accounts: [`0x${PRIVATE_KEY}`]
      }
   },
}


/* Arbitrum Deplpy */
// module.exports = {
//    solidity: "0.7.3",
//    defaultNetwork: "arbitrum",
//    networks: {
//       arbitrum: {
//          url: 'https://rinkeby.arbitrum.io/rpc',
//          accounts: [`0x${PRIVATE_KEY}`]
//       },
//    },
// }


/* Matic Deploy */
// module.exports = {
//    defaultNetwork: "matic",
//    solidity: "0.7.3",
//    networks: {
//       matic: {
//          url: "https://rpc-mumbai.maticvigil.com",
//          accounts: [`0x${PRIVATE_KEY}`]
//       },
//    },
// }


/* IOTA Deploy */
// module.exports = {
//    defaultNetwork: "iota",
//    solidity: "0.7.3",
//    networks: {
//       iota: {
//          url: "https://evm.wasp.sc.iota.org",
//          accounts: [`0x${PRIVATE_KEY}`]
//       },
//    },
// }